"use client";
import { AppShell } from "@/components/AppShell";
export default function SettingsPage(){
  return (<AppShell>
    <h1 className="text-2xl font-bold mb-4">Organization Settings</h1>
    <div className="card">Org name, branding, webhooks (insurers, FactorFox). Admin-only actions.</div>
  </AppShell>);
}
