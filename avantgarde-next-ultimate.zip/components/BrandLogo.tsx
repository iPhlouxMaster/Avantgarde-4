export function BrandLogo({className=""}:{className?:string}){
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className="h-3 w-3 rounded-full bg-primary"></div>
      <span className="font-semibold tracking-wide">Avantgarde</span>
    </div>
  );
}
