export async function safePost(path: string, body: unknown) {
  const base = process?.env?.NEXT_PUBLIC_EDGE_WRAPPER_URL;
  if (!base) return { ok:false, error:"Set NEXT_PUBLIC_EDGE_WRAPPER_URL" };
  try {
    const res = await fetch(`${base}${path}`, { method:"POST", headers:{"content-type":"application/json"}, body: JSON.stringify(body), cache:"no-store" });
    if (!res.ok) return { ok:false, error:`HTTP ${res.status}` };
    return { ok:true, data: await res.json() };
  } catch (e:any) { return { ok:false, error: e?.message || "Network error" }; }
}
