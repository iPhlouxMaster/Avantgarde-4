import Link from "next/link";
export default function LegalIndex(){
  return (
    <div className="max-w-3xl mx-auto p-6 mt-10 space-y-3">
      <h1 className="text-2xl font-bold">Legal</h1>
      <ul className="list-disc pl-6">
        <li><Link href="/legal/terms">Terms of Service</Link></li>
        <li><Link href="/legal/privacy">Privacy Policy</Link></li>
      </ul>
    </div>
  );
}
