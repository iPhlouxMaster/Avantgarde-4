export default function Privacy(){
  return (
    <div className="max-w-3xl mx-auto p-6 mt-10 card space-y-3">
      <h1 className="text-2xl font-bold">Privacy Policy</h1>
      <p className="text-muted">Template — replace with your privacy counsel text.</p>
      <ul className="list-disc pl-6 text-sm text-muted space-y-1">
        <li>We collect account data (email), org membership, and operational events.</li>
        <li>We use third-party services (Supabase, hosting provider) to operate the app.</li>
        <li>We retain activity logs for security and compliance.</li>
        <li>Contact your administrator for data access requests.</li>
      </ul>
    </div>
  );
}
