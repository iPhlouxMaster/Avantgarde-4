export type Role = "admin" | "analyst" | "viewer";
export const can = {
  viewAdmin: (role: Role) => role === "admin",
  manageUsers: (role: Role) => role === "admin",
  viewAnalytics: (role: Role) => role === "admin" || role === "analyst",
};
