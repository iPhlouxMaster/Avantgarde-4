"use client";
import { AppShell } from "@/components/AppShell";
import { useEffect, useState } from "react";

export default function Dashboard(){
  const [kpi,setKpi]=useState<any>({});
  useEffect(()=>{ setKpi({ nav: 12500000, exposure: 8200000, policies: 87, defaultRate: "1.8%" }); },[]);
  return (
    <AppShell>
      <div className="grid md:grid-cols-4 gap-4">
        <div className="kpi"><div className="text-sm text-muted">Total NAV</div><div className="text-2xl font-bold">${"{".replace("{","")}{kpi.nav?.toLocaleString?.()||"–"}</div></div>
        <div className="kpi"><div className="text-sm text-muted">Insured Exposure</div><div className="text-2xl font-bold">${"{".replace("{","")}{kpi.exposure?.toLocaleString?.()||"–"}</div></div>
        <div className="kpi"><div className="text-sm text-muted">Active Policies</div><div className="text-2xl font-bold">{kpi.policies||"–"}</div></div>
        <div className="kpi"><div className="text-sm text-muted">Default Rate</div><div className="text-2xl font-bold">{kpi.defaultRate||"–"}</div></div>
      </div>
      <div className="mt-6 card">
        <h2 className="text-xl font-semibold mb-2">Recent Activity</h2>
        <p className="text-muted">Wire up to Supabase `audit_log` or `events` for live feed.</p>
      </div>
    </AppShell>
  );
}
