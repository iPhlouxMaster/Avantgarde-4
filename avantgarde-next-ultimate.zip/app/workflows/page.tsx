"use client";
import { AppShell } from "@/components/AppShell";
export default function WorkflowsPage(){
  return (<AppShell>
    <h1 className="text-2xl font-bold mb-4">Workflows</h1>
    <div className="grid md:grid-cols-2 gap-4">
      <div className="card"><h2 className="font-semibold mb-2">Good Path</h2><ul className="list-disc pl-6 text-muted"><li>Revaluation</li><li>Securitization</li><li>Credit expansion</li></ul></div>
      <div className="card"><h2 className="font-semibold mb-2">Bad Path</h2><ul className="list-disc pl-6 text-muted"><li>Insurance payout</li><li>Secondary sale</li><li>Gov disposition</li></ul></div>
    </div>
  </AppShell>);
}
