export default function Terms(){
  return (
    <div className="max-w-3xl mx-auto p-6 mt-10 card space-y-3">
      <h1 className="text-2xl font-bold">Terms of Service</h1>
      <p className="text-muted">Template — replace with counsel-approved language.</p>
      <ul className="list-disc pl-6 text-sm text-muted space-y-1">
        <li>Use of the service is subject to account verification and credit approval.</li>
        <li>Data processing is governed by agreements with insurance and factoring partners.</li>
        <li>No warranties; service is provided “as is”.</li>
        <li>Governing law and venue to be specified.</li>
      </ul>
    </div>
  );
}
