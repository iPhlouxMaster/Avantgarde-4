# Avantgarde Console — Ultimate Build (RBAC + Legal + Health + Status + Branding)

Everything wired from our checklist: server redirect, health route, status page, RBAC shell,
legal placeholders, tokens pipeline, and deploy check.

## Run local
```bash
pnpm i
cp .env.example .env
pnpm tokens
pnpm dev
```

## Deploy (Vercel)
1) Push to GitHub → Import on Vercel.
2) Add envs:
   - NEXT_PUBLIC_SUPABASE_URL
   - NEXT_PUBLIC_SUPABASE_ANON_KEY
   - NEXT_PUBLIC_EDGE_WRAPPER_URL
3) Deploy. Build runs `npm run tokens` automatically.

### Post-deploy checks
- Open `/status` and `/api/health` on the **latest deployment URL**.
- If 404, verify Vercel **Root Directory** points to this project root and there is **no** `next.config.ts` in the repo.

## Supabase
Run `supabase/schema_rbac.sql` in the SQL editor; add `orgs`, `profiles`, and `members` rows.

## Figma
Use Tokens Studio → export to `design/tokens.json` → redeploy. Hook webhooks to your CI if needed.

