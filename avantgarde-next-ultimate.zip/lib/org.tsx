"use client";
import { createContext, useContext, useEffect, useState } from "react";
import { supabase } from "./supabase";

type Org = { id: string; name: string };
type OrgCtx = {
  org: Org | null;
  role: "admin"|"analyst"|"viewer" | null;
  orgs: Org[];
  setOrgId: (id: string)=>void;
};

const Ctx = createContext<OrgCtx>({ org: null, role: null, orgs: [], setOrgId: ()=>{} });

export function OrgProvider({ children }: { children: React.ReactNode }) {
  const [orgs,setOrgs]=useState<Org[]>([]);
  const [org,setOrg]=useState<Org|null>(null);
  const [role,setRole]=useState<"admin"|"analyst"|"viewer"|null>(null);

  useEffect(()=>{
    (async ()=>{
      const { data: members } = await supabase.from("members").select("org_id, role, orgs:org_id ( id, name )");
      const list: Org[] = (members||[]).map((m:any)=>m.orgs);
      setOrgs(list);
      const stored = localStorage.getItem("orgId");
      const current = list.find(o=>o.id===stored) || list[0] || null;
      setOrg(current);
      if (current) {
        const me = (members||[]).find((m:any)=>m.org_id===current.id);
        setRole(me?.role || null);
      }
    })();
  },[]);

  function setOrgId(id:string){
    localStorage.setItem("orgId", id);
    const o = orgs.find(x=>x.id===id) || null;
    setOrg(o);
  }

  return <Ctx.Provider value={{ org, role, orgs, setOrgId }}>{children}</Ctx.Provider>;
}

export function useOrg(){ return useContext(Ctx); }
