import http from "node:https";

const url = process.env.DEPLOY_URL || "http://localhost:3000/api/health";
http.get(url, (res) => {
  let data = "";
  res.on("data", c => data += c);
  res.on("end", () => {
    console.log("Status:", res.statusCode);
    console.log("Body:", data);
    try { const j = JSON.parse(data); if (j.ok) process.exit(0); else process.exit(1); }
    catch { process.exit(res.statusCode === 200 ? 0 : 1); }
  });
}).on("error", (e) => {
  console.error("Check failed:", e.message);
  process.exit(1);
});
