"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { clsx } from "clsx";
import { useOrg } from "@/lib/org";
import { BarChart3, Briefcase, ShieldCheck, Layers, Workflow, Users, Settings, Home, FileText, HeartPulse } from "lucide-react";

const items = [
  { href: "/dashboard", label: "Dashboard", icon: Home },
  { href: "/assets", label: "Assets", icon: Briefcase },
  { href: "/policies", label: "Policies", icon: ShieldCheck },
  { href: "/pools", label: "Pools", icon: Layers },
  { href: "/workflows", label: "Workflows", icon: Workflow },
  { href: "/analytics", label: "Analytics", icon: BarChart3 },
  { href: "/admin/users", label: "Users", icon: Users, role: "admin" },
  { href: "/settings", label: "Settings", icon: Settings },
  { href: "/legal", label: "Legal", icon: FileText },
  { href: "/status", label: "Status", icon: HeartPulse }
];

export function Sidebar(){
  const path = usePathname();
  const { role } = useOrg();
  return (
    <aside className="w-64 shrink-0 h-screen sticky top-0 p-4 bg-surface border-r border-[#1b2330]">
      <div className="text-xs uppercase tracking-widest text-muted mb-3">Navigation</div>
      <nav className="flex flex-col gap-1">
        {items.filter(i=>!i.role || i.role===role).map(i=>{
          const Icon = i.icon as any;
          const active = path?.startsWith(i.href);
          return (
            <Link key={i.href} href={i.href} className={clsx("sidebar-link", active && "sidebar-link-active")}>
              <Icon className="h-4 w-4" /><span>{i.label}</span>
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
