/** @type {import('next').NextConfig} */
let nextConfig = {};
try {
  nextConfig = {
    reactStrictMode: true,
    experimental: { typedRoutes: true }
  };
} catch (err) {
  console.error("Next config error:", err);
  nextConfig = { reactStrictMode: true };
}
export default nextConfig;
