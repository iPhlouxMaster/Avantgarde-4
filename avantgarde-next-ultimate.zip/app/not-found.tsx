export default function NotFound(){
  return (
    <div className="min-h-screen grid place-items-center">
      <div className="card max-w-md text-center">
        <h1 className="text-2xl font-bold mb-2">404 — Not Found</h1>
        <p className="text-muted">This page doesn’t exist. Check the URL or return to the dashboard.</p>
        <a href="/dashboard" className="btn btn-primary mt-4 inline-block">Go to Dashboard</a>
      </div>
    </div>
  );
}
