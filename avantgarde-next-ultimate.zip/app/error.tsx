"use client";
export default function Error({ error }: { error: Error }){
  return (
    <div className="min-h-screen grid place-items-center">
      <div className="card max-w-md text-center">
        <h1 className="text-2xl font-bold mb-2">Something went wrong</h1>
        <p className="text-muted">{error?.message || "Unknown error"}</p>
        <a href="/dashboard" className="btn btn-primary mt-4 inline-block">Back to Dashboard</a>
      </div>
    </div>
  );
}
