"use client";
import { AppShell } from "@/components/AppShell";
export default function AnalyticsPage(){
  return (<AppShell>
    <h1 className="text-2xl font-bold mb-4">Analytics</h1>
    <div className="card">Charts placeholder — exposure by insurer, pool performance, DSO trends.</div>
  </AppShell>);
}
