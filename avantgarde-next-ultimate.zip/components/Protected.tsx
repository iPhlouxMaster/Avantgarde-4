"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

export function Protected({ children }:{ children: React.ReactNode }){
  const [ok,setOk]=useState(false);
  useEffect(()=>{ (async()=>{
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) location.href="/auth"; else setOk(true);
  })(); },[]);
  if (!ok) return null;
  return <>{children}</>;
}
