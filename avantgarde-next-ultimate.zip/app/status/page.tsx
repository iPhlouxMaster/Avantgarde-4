export default function Status() {
  return (
    <div className="min-h-screen grid place-items-center">
      <div className="card max-w-md text-center">
        <h1 className="text-2xl font-bold mb-2">App is deployed ✅</h1>
        <p className="text-muted">Try <a href="/dashboard">/dashboard</a> or <a href="/auth">/auth</a>.</p>
      </div>
    </div>
  );
}
